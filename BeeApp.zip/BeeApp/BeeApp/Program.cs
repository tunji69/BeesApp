﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BeeApp
{
    class beeProgram
    {

        public List<Bee> beeList;

        public void initialiseList()
        {
            beeList = new List<Bee>();
            int count = 0;

            for (; count < 10; count++)
            {
                beeList.Add(new Queen());
            }

            for (; count < 20; count++)
            {
                beeList.Add(new Drone());
            }

            for (; count < 30; count++)
            {
                beeList.Add(new Worker());
            }
        }

        public void damageBee(int pos, int percentDamage)
        {
            if (beeList != null && (pos >= 0 && pos < 30) && (percentDamage >= 0 && percentDamage <= 100))
            {
                beeList[pos].Damage(percentDamage);
            }
        }

        public string beeHealthStatus(int pos)
        {

            if (beeList != null)
            {
                return "Bees list not initalised";
            }


            if (pos >= 0 && pos <= 100)
            {
                if (beeList[pos].Dead)
                    return "Bee is Dead";

                return "Bee is Alive";
            }

            return "Bee doesn't exist at that position";

        }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            beeProgram beeApp = new beeProgram();

            beeApp.initialiseList();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());


        }
    }
}
