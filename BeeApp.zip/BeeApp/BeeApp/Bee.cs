﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeApp
{
    public abstract class Bee
    {
        public bool Dead 
        {
            get;
            set;
        }
        public Bee ()
        {
            Health = 100.0F;
            Dead = false;
        }
        protected float Health
        {
            get;
            set;
        }
        protected void reduceHealth(int reduceBy)
        {
            if (Health > reduceBy)
            {
                Health -= reduceBy;
            }
            else
            {
                Health = 0;
            }
        }

        public abstract void Damage(int percentDamage);

    }
}
