﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeApp
{
    class Queen : Bee
    {

        public override void Damage(int percentDamage)
        {
            if (!Dead)
            {
                reduceHealth(percentDamage);
                if (Health < 20)
                {
                    Dead = true;
                }
            }
        }
    }
}
