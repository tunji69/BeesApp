﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeeApp
{
    class Worker : Bee
    {

        public override void Damage(int percentDamage)
        {
            if (!Dead)
            {
                reduceHealth(percentDamage);
                if (Health < 70)
                {
                    Dead = true;
                }
            }
        }
    }
}
